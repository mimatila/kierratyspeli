# kierratyspeli
Pelissä on tarkoitus lajitella eri jätteet omiin astioihinta.
Max tulos on 15/15.
